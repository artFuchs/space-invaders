﻿Para compilar o código deve-se utilizar do Visual Studio, pois é utilizado a library Forms, entre outras, que fazem parte do pacote da IDE do VS.

Caso não possua o Visual Studio, acesse o site: https://www.visualstudio.com e baixe a versão Free (Community 2017). Também é necessário instalar o Microsoft .NET.
Para executar o programa, usar o .exe na pasta Release
